<?php
class NaiveBayes
{
    private $categoryCounts = [];
    private $wordCounts = [];
    private $vocab = [];

    private $dictionary = [];

    public function train(array $documents, array $labels)
    {
        $this->categoryCounts = [];
        $this->wordCounts = [];
        $this->vocab = [];
        $this->incrementalTrain($documents, $labels);
    }

    public function incrementalTrain(array $documents, array $labels)
    {
        if (count($documents) !== count($labels)) {
            throw new Exception('文档数和标签数不一致');
        }

        foreach ($documents as $i => $doc) {
            $words = $this->tokenize($doc);
            $label = $labels[$i];

            if (!isset($this->categoryCounts[$label])) {
                $this->categoryCounts[$label] = 0;
                $this->wordCounts[$label] = [];
            }
            $this->categoryCounts[$label]++;

            foreach ($words as $word) {
                if (!isset($this->wordCounts[$label][$word])) {
                    $this->wordCounts[$label][$word] = 0;
                }
                $this->wordCounts[$label][$word]++;
                $this->vocab[$word] = true;
            }
        }
    }

    public function predict($text, $uniformPrior = true)
    {
        $words = $this->tokenize($text);
        $scores = [];
        $totalDocs = array_sum($this->categoryCounts);
        $vocabSize = count($this->vocab);
        $numCategories = count($this->categoryCounts);

        foreach ($this->categoryCounts as $label => $count) {
            // 先验概率：均匀先验 或 基于频率的先验
            if ($uniformPrior) {
                $score = log(1 / $numCategories);
            } else {
                $score = log($count / $totalDocs);
            }

            $totalWordsInCat = array_sum($this->wordCounts[$label] ?? []);

            foreach ($words as $word) {
                $freq = $this->wordCounts[$label][$word] ?? 0;
                // 拉普拉斯平滑
                $score += log(($freq + 1) / ($totalWordsInCat + $vocabSize));
            }
            $scores[$label] = $score;
        }

        // 找出最高分的类别
        arsort($scores);
        $bestLabel = key($scores);
        $bestScore = reset($scores);

        // 使用 log-sum-exp 计算归一化概率
        $sumExp = 0;
        foreach ($scores as $label => $score) {
            $sumExp += exp($score - $bestScore);
        }
        $probability = 1 / $sumExp;

        return [
            'label' => $bestLabel,
            'probability' => round($probability, 6),
            'scores' => $scores
        ];
    }

    public function save($file)
    {
        $data = [
            'categoryCounts' => $this->categoryCounts,
            'wordCounts' => $this->wordCounts,
            'vocab' => array_keys($this->vocab)
        ];
        file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE));
    }

    /**
     * 从 JSON 文件加载模型
     */
    public function load($file)
    {
        if (!file_exists($file)) {
            throw new Exception('模型文件不存在: ' . $file);
        }
        $data = json_decode(file_get_contents($file), true);
        $this->categoryCounts = $data['categoryCounts'];
        $this->wordCounts = $data['wordCounts'];
        $this->vocab = array_flip($data['vocab']);
    }

    /**
     * 设置词典（会覆盖原有词典）
     */
    public function setDictionary(array $dict)
    {
        $this->dictionary = $this->sortDictionary($dict);
    }

    public function addDictionary(array $newWords)
    {
        $this->dictionary = array_merge($this->dictionary, $newWords);
        $this->dictionary = $this->sortDictionary($this->dictionary);
    }

    /**
     * 保存词典到文件
     */
    public function saveDictionary($file)
    {
        file_put_contents($file, json_encode($this->dictionary, JSON_UNESCAPED_UNICODE));
    }

    /**
     * 从文件加载词典
     */
    public function loadDictionary($file)
    {
        if (file_exists($file)) {
            $dict = json_decode(file_get_contents($file), true);
            if (is_array($dict)) {
                $this->dictionary = $this->sortDictionary($dict);
            }
        }
    }


    public function extractNewWords(array $documents, $minFreq = 3, $maxLen = 4)
    {
        $counter = [];
        foreach ($documents as $doc) {
            // 清理文本，仅保留中文字符
            $clean = preg_replace('/[^\x{4e00}-\x{9fa5}]/u', '', mb_strtolower($doc));
            $len = mb_strlen($clean);
            for ($i = 0; $i < $len; $i++) {
                for ($l = 2; $l <= $maxLen; $l++) {
                    if ($i + $l > $len) break;
                    $sub = mb_substr($clean, $i, $l);
                    if (!isset($counter[$sub])) {
                        $counter[$sub] = 0;
                    }
                    $counter[$sub]++;
                }
            }
        }
        $newWords = [];
        foreach ($counter as $word => $freq) {
            if ($freq >= $minFreq && !in_array($word, $this->dictionary)) {
                $newWords[] = $word;
            }
        }
        return $newWords;
    }

    private function tokenize($text)
    {
        // 转为小写
        $text = mb_strtolower($text);
        // 去除标点、特殊符号，只保留字母、数字、中文
        $text = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $text);
        $text = trim($text);
        if ($text === '') return [];

        // 按空格分割（处理英文/数字与中文的混合）
        $segments = preg_split('/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
        $tokens = [];

        foreach ($segments as $segment) {
            // 纯英文/数字部分
            if (preg_match('/^[a-z0-9]+$/i', $segment)) {
                $expanded = $this->expandRepeatedToken($segment);
                $tokens = array_merge($tokens, $expanded);
                continue;
            }

            // 中英混合，逐字符处理：英文字母/数字与中文分开
            $mixedTokens = preg_split('/(?<=[a-z0-9])(?=[\x{4e00}-\x{9fa5}])|(?<=[\x{4e00}-\x{9fa5}])(?=[a-z0-9])/iu', $segment, -1, PREG_SPLIT_NO_EMPTY);
            foreach ($mixedTokens as $tok) {
                if (preg_match('/^[a-z0-9]+$/i', $tok)) {
                    $expanded = $this->expandRepeatedToken($tok);
                    $tokens = array_merge($tokens, $expanded);
                } else {
                    // 中文部分，调用正向最大匹配
                    $tokens = array_merge($tokens, $this->maxMatch($tok));
                }
            }
        }

        return $tokens;
    }

    private function expandRepeatedToken($token)
    {
        $len = strlen($token);
        if ($len < 4) return [$token]; // 太短不处理

        // 寻找最小重复周期
        for ($period = 1; $period <= intval($len / 2); $period++) {
            if ($len % $period == 0) {
                $unit = substr($token, 0, $period);
                $repeated = true;
                for ($i = $period; $i < $len; $i += $period) {
                    if (substr($token, $i, $period) !== $unit) {
                        $repeated = false;
                        break;
                    }
                }
                if ($repeated) {
                    // 限制最大重复次数，防止 token 爆炸
                    $times = min(intval($len / $period), 20);
                    return array_fill(0, $times, $unit);
                }
            }
        }
        return [$token];
    }

    private function maxMatch($chineseText)
    {
        $result = [];
        $len = mb_strlen($chineseText);
        $start = 0;
        $maxWordLen = 0;
        foreach ($this->dictionary as $word) {
            $maxWordLen = max($maxWordLen, mb_strlen($word));
        }
        // 如果词典为空，设置最大长度为1，只切分单字
        if ($maxWordLen == 0) $maxWordLen = 1;

        while ($start < $len) {
            $matched = false;
            for ($l = $maxWordLen; $l > 0; $l--) {
                if ($start + $l > $len) continue;
                $sub = mb_substr($chineseText, $start, $l);
                if (in_array($sub, $this->dictionary)) {
                    $result[] = $sub;
                    $start += $l;
                    $matched = true;
                    break;
                }
            }
            if (!$matched) {
                $result[] = mb_substr($chineseText, $start, 1);
                $start++;
            }
        }
        return $result;
    }

    private function sortDictionary(array $dict)
    {
        $dict = array_values(array_unique($dict));
        usort($dict, function ($a, $b) {
            $lenA = mb_strlen($a);
            $lenB = mb_strlen($b);
            if ($lenA == $lenB) {
                return strcmp($a, $b);
            }
            return $lenB - $lenA;
        });
        return $dict;
    }
}